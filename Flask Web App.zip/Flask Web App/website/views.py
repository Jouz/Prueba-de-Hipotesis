import math
from os import truncate
from flask import Blueprint
from flask import request
from decimal import Decimal as D
import statistics
import numpy as np
from scipy import stats

views = Blueprint('views', __name__)

@views.route('/')
def home():
    proveedor1 = str(request.args.get("proveedor1", ""))
    listaProveedor1 = proveedor1.split(",")
    
    proveedor2 = str(request.args.get("proveedor2", ""))
    listaProveedor2 = proveedor2.split(",")

    significancia = str(request.args.get("significancia", ""))
    listaSignificancia = significancia.split(" ")
    area = str(1-(float(significancia)/2))
        
    promedio1 = calcular_promedio(listaProveedor1)
    promedio2 = calcular_promedio(listaProveedor2)
    promedio3 = promedio_hipotesis(listaProveedor1, listaProveedor2)

    desviacion1 = calcular_varianza(listaProveedor1)
    desviacion2 = calcular_varianza(listaProveedor2)
    alpha = calcular_z(significancia)

    calculoZ1 = calcular_formulaz(listaProveedor1, listaProveedor2)
    calculoZ2 = calcular_formulaz(listaProveedor2, listaProveedor1)

    return (
        """
        <!DOCTYPE html>
        <hyml>
        <body style="background-color:powderblue;">
        <form action="" method="get" class="form-example" align="center"> 
            <div class="form-example">
            <br>
            <h1>Datos Utilizados</h1>
            <br>
                <label for="datos1" justify="left">Datos Proveedor 1: </label>
                <input type="text" name="proveedor1" id="proveedor1" required>
            </div>
            <br>
            <div class="form-example">
                <label for="datos2">Datos Proveedor 2: </label>
                <input type="text" name="proveedor2" id="proveedor2" required>
            </div>
            <br>
            <div class="form-example">
                <label for="significancia">Nivel Significancia: </label>
                <input type="text" name="significancia" id="significancia" required>
            </div>
            <br>
            <div>
                <h2>Hipótesis Planteada</h2>
                <h3>Ho : σ²1 = σ²2 </h3>
                <h3>H1 : σ²1 ≠ σ²2 </h3>
            </div>
            
            <div class="form-example">
                <input type="submit" value="Calcular" style="transform: translate(2.2%);
   padding: 3px;
   margin-top: 0.6rem;
   font-family: cursive;
   font-weight: bold">
            </div>
        
        </form>"""     
        + "<br>"
        + """<form action="" method="get" class="form-example" align="center">
        <div class="form-example">
        <h2>Resultados</h2>
        </div>
        <div class="form-example">
        <h3 style="float: left; width: 50%;">Proveedor 1</h3>
        </div>
        </form><br><br><br><br>"""
        
        + """<label style="float: right; width: 100%;">μh Promedio Hipótesis: """ + promedio3 + "<br><br>"
        + """<label style="float: right; width: 100%;">Valor crítico de Z: entre -""" + alpha + " y " + alpha + "<br>"
        + """<label style="float: right; width: 100%;">α Area de significancia Z : """ + area + "<br><br>"

        + "x̄ Proveedor 1: " + promedio1 + "<br>"
        + "σ1 Proveedor 1: " + desviacion1 + "<br>"
        + "Cálculo de Z Proveedor 1: " + calculoZ1 + "<br>"

        + """<form action="" method="get" class="form-example" align="center">
        <div class="form-example">
        <h3 style="float: left; width: 50%">Proveedor 2</h3>
        </div>
        </form><br><br><br><br>"""

        + "μh Promedio Hipótesis: " + promedio3 + "<br><br>"
        + "Valor crítico de Z: entre -""" + alpha + " y " + alpha + "<br>"
        + "α Area de significancia Z: " + area + "<br><br>"

        + "x̄ Proveedor 2: " + promedio2 + "<br>"
        + "σ2 Proveedor 2: " + desviacion2 + "<br>"
        + "Cálculo de Z Proveedor 2: " + calculoZ2 + "<br>"
        + "</body><br><br><br>"
        + "</html>"
    )

def calcular_promedio(listaProveedor):
    try:
        promedio = [float(x) for x in listaProveedor]
        
        return str(statistics.fmean(promedio))
    except ValueError:
        return "Datos No Válidos"

def promedio_hipotesis(lista1, lista2):
    try:
        promedio = [float(x) for x in lista1]
        promedio += [float(x) for x in lista2]

        return str(statistics.fmean(promedio))
    except ValueError:
        return "Datos No Válidos"

def calcular_varianza(listaProveedor):
    try:
        desviacion = [float(x) for x in listaProveedor]
        
        return str(round(statistics.variance(desviacion), 3))
    except ValueError:
        return "Datos No Válidos"

def calcular_z(porcentage):
    try:
        significancia = float(porcentage)
        colas = 2
        z = stats.norm.ppf(1-(significancia / 2))
        z = round(z, 2)
        return str(z)
    except ValueError:
        return "Datos No Válidos"

def calcular_formulaz (lista1, lista2):
    try:
        promedio = calcular_promedio(lista1)
        promedioHipotesis = promedio_hipotesis(lista1, lista2)
        varianza = calcular_varianza(lista1)
        muestra = len(lista1)
        calculo = (float(promedio) - float(promedioHipotesis)) / (float(varianza) / float(math.sqrt(muestra)))
        return str(round(calculo,2))

    except ValueError:
        return "Datos No Válidos"